#include <gtest/gtest.h>

#include "../src/audio/audio.h"
#include "../src/common/constants.h"
#include "../src/cpu/cpu.h"
#include "../src/display/display.h"
#include "../src/input/input.h"
#include "../src/memory/memory.h"

class CPUTest : public ::testing::Test {
 protected:
  Memory mem;
  Display display;
  Keypad keypad;
  Audio audio;
  std::unique_ptr<CPU> cpu;

  void SetUp() override {
    // Initialize the CPU with our headless subsystems
    cpu = std::make_unique<CPU>(mem, display, keypad, audio);

    // Reset PC to standard start address before every test
    cpu->set_pc(Chip8::ROM_START);
  }

  // Helper method to write a 2-byte opcode directly into the memory array
  void inject_opcode(uint16_t address, uint16_t opcode) {
    mem.write(address, (opcode & 0xFF00) >> 8);
    mem.write(address + 1, opcode & 0x00FF);
  }
};

// ==========================================
// FLOW CONTROL & SKIPS
// ==========================================

TEST_F(CPUTest, Opcode1NNN_JumpToAddress) {
  inject_opcode(0x200, 0x1ABC);
  cpu->cycle();
  EXPECT_EQ(cpu->get_pc(), 0xABC);
}

TEST_F(CPUTest, Opcode3XNN_SkipIfEqual_True) {
  cpu->set_register(5, 0x42);
  inject_opcode(0x200, 0x3542);  // Skip if V5 == 0x42
  cpu->cycle();
  EXPECT_EQ(cpu->get_pc(), 0x204);  // Skipped (PC + 4)
}

TEST_F(CPUTest, Opcode3XNN_SkipIfEqual_False) {
  cpu->set_register(5, 0x11);
  inject_opcode(0x200, 0x3542);  // Skip if V5 == 0x42
  cpu->cycle();
  EXPECT_EQ(cpu->get_pc(), 0x202);  // Did not skip (PC + 2)
}

// ==========================================
// BASIC ARITHMETIC & ASSIGNMENT
// ==========================================

TEST_F(CPUTest, Opcode6XNN_SetRegister) {
  inject_opcode(0x200, 0x63AB);  // Set V3 to 0xAB
  cpu->cycle();
  EXPECT_EQ(cpu->get_register(3), 0xAB);
}

TEST_F(CPUTest, Opcode7XNN_AddValueToRegister) {
  cpu->set_register(1, 10);
  inject_opcode(0x200, 0x7105);  // Add 5 to V1
  cpu->cycle();
  EXPECT_EQ(cpu->get_register(1), 15);
}

// ==========================================
// COMPLEX ARITHMETIC (FLAGS)
// ==========================================

TEST_F(CPUTest, Opcode8XY4_AddWithoutCarry) {
  cpu->set_register(0, 100);
  cpu->set_register(1, 50);
  inject_opcode(0x200, 0x8014);  // Add V1 to V0
  cpu->cycle();

  EXPECT_EQ(cpu->get_register(0), 150);
  EXPECT_EQ(cpu->get_register(0xF), 0);  // No overflow, carry is 0
}

TEST_F(CPUTest, Opcode8XY4_AddWithCarry) {
  cpu->set_register(0, 250);
  cpu->set_register(1, 10);
  inject_opcode(0x200, 0x8014);  // Add V1 to V0
  cpu->cycle();

  EXPECT_EQ(cpu->get_register(0), 4);    // 260 rolls over to 4
  EXPECT_EQ(cpu->get_register(0xF), 1);  // Overflowed, carry is 1
}

TEST_F(CPUTest, Opcode8XY5_SubtractWithoutUnderflow) {
  cpu->set_register(0, 100);
  cpu->set_register(1, 40);
  inject_opcode(0x200, 0x8015);  // Subtract V1 from V0
  cpu->cycle();

  EXPECT_EQ(cpu->get_register(0), 60);
  EXPECT_EQ(cpu->get_register(0xF), 1);  // No underflow, borrow is 1
}

TEST_F(CPUTest, Opcode8XY5_SubtractWithUnderflow) {
  cpu->set_register(0, 40);
  cpu->set_register(1, 100);
  inject_opcode(0x200, 0x8015);  // Subtract V1 from V0
  cpu->cycle();

  EXPECT_EQ(cpu->get_register(0), 196);  // 40 - 100 wraps around to 196
  EXPECT_EQ(cpu->get_register(0xF), 0);  // Underflowed, borrow is 0
}

// ==========================================
// MEMORY & INDEX REGISTER
// ==========================================

TEST_F(CPUTest, OpcodeANNN_SetIndexRegister) {
  inject_opcode(0x200, 0xA123);  // Set I to 0x123
  cpu->cycle();
  // Assuming you have a get_index_register() or similar method in your public API
  // If not, you will need to add it to cpu.h just like get_register!
  EXPECT_EQ(cpu->get_index_register(), 0x123);
}

TEST_F(CPUTest, OpcodeFX55_RegisterDump) {
  // Populate V0 through V2
  cpu->set_register(0, 0xAA);
  cpu->set_register(1, 0xBB);
  cpu->set_register(2, 0xCC);

  // Set Index Register to an arbitrary safe memory space
  cpu->set_index_register(0x400);

  inject_opcode(0x200, 0xF255);  // Dump V0 through V2 into memory starting at I
  cpu->cycle();

  EXPECT_EQ(mem.read(0x400), 0xAA);
  EXPECT_EQ(mem.read(0x401), 0xBB);
  EXPECT_EQ(mem.read(0x402), 0xCC);
}

TEST_F(CPUTest, OpcodeFX65_RegisterLoad) {
  // Pre-load memory with specific bytes
  mem.write(0x500, 0x11);
  mem.write(0x501, 0x22);

  cpu->set_index_register(0x500);

  inject_opcode(0x200, 0xF165);  // Load memory starting at I into V0 through V1
  cpu->cycle();

  EXPECT_EQ(cpu->get_register(0), 0x11);
  EXPECT_EQ(cpu->get_register(1), 0x22);
}
