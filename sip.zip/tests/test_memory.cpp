#include <gtest/gtest.h>

#include "../src/common/constants.h"
#include "../src/memory/memory.h"

class MemoryTest : public ::testing::Test {
 protected:
  Memory mem;
};

TEST_F(MemoryTest, InitialStateIsZero) {
  EXPECT_EQ(mem.read(Chip8::ROM_START), 0x00);
}

TEST_F(MemoryTest, ReadWriteValidMemory) {
  mem.write(0x200, 0xAB);
  EXPECT_EQ(mem.read(0x200), 0xAB);
}

TEST_F(MemoryTest, FontIsLoadedOnBoot) {
  EXPECT_EQ(mem.read(Chip8::FONT_START), 0xF0);
}

TEST_F(MemoryTest, OutOfBoundsWriteThrows) {
  EXPECT_THROW(mem.write(Chip8::MEMORY_SIZE + 1, 0xFF), std::runtime_error);
}
